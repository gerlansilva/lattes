# Painel ScriptLattes no Streamlit

Aplicação Streamlit para executar o `scriptLattes`, gerar relatórios automaticamente e explorar os arquivos JSON produzidos por pesquisador.

## Estrutura do projeto

```text
meu-scriptlattes-app/
├── app.py
├── requirements.txt
├── packages.txt
├── .gitignore
├── README.md
└── scriptLattes-main/
    ├── scriptLattes.py
    ├── chromedriver
    ├── css/
    ├── js/
    └── scriptLattes/
```

## O que já está incluído neste pacote

- `app.py` pronto para rodar no Streamlit
- `requirements.txt` com dependências Python
- `packages.txt` para Streamlit Community Cloud
- `.gitignore` para não subir arquivos temporários
- `scriptLattes-main/` incluído no pacote
- ajuste em `scriptLattes/scriptLattes/baixaLattes.py` para priorizar o Chrome/Chromium do Linux no deploy

## Como rodar localmente

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Como publicar no GitHub

1. Crie um repositório novo no GitHub.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Confirme que `app.py`, `requirements.txt`, `packages.txt` e `scriptLattes-main/` ficaram no mesmo nível.

Exemplo via terminal:

```bash
git init
git add .
git commit -m "Primeira versão do app ScriptLattes"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

## Como publicar no Streamlit Community Cloud

1. Entre no Streamlit Community Cloud.
2. Clique em **Create app**.
3. Escolha o repositório do GitHub.
4. Selecione a branch `main`.
5. No campo **Main file path**, informe `app.py`.
6. Faça o deploy.

## Observações importantes

- O ambiente precisa ter Python e dependências do Selenium.
- No Streamlit Cloud, o arquivo `packages.txt` ajuda a instalar `chromium` e `chromium-driver`.
- O processamento depende da disponibilidade do site do Lattes e pode falhar em momentos de instabilidade externa.
- Se o deploy em nuvem apresentar bloqueios do navegador ou do site do CNPq, a execução local costuma ser mais estável.

## O que o app faz

- recebe arquivo `.list` ou IDs digitados manualmente;
- cria o `.config` automaticamente;
- executa o `scriptLattes.py`;
- lê os JSONs individuais gerados pelo scriptLattes;
- mostra métricas, tabelas e filtros;
- permite baixar CSVs e a pasta completa de saída em `.zip`.
